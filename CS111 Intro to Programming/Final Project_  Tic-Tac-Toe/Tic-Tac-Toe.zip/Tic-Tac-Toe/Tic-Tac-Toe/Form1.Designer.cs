﻿namespace Tic_Tac_Toe
{
    partial class TicTacToe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TicTacToe));
            this.grid = new System.Windows.Forms.PictureBox();
            this.square1 = new System.Windows.Forms.Label();
            this.square2 = new System.Windows.Forms.Label();
            this.square3 = new System.Windows.Forms.Label();
            this.square4 = new System.Windows.Forms.Label();
            this.square5 = new System.Windows.Forms.Label();
            this.square6 = new System.Windows.Forms.Label();
            this.square7 = new System.Windows.Forms.Label();
            this.square8 = new System.Windows.Forms.Label();
            this.square9 = new System.Windows.Forms.Label();
            this.clear = new System.Windows.Forms.Button();
            this.playerXLabel = new System.Windows.Forms.Label();
            this.playerYLabel = new System.Windows.Forms.Label();
            this.OScore = new System.Windows.Forms.Label();
            this.XScore = new System.Windows.Forms.Label();
            this.turnLabel = new System.Windows.Forms.Label();
            this.tiesLabel = new System.Windows.Forms.Label();
            this.TieScore = new System.Windows.Forms.Label();
            this.XPercent = new System.Windows.Forms.Label();
            this.Percent1 = new System.Windows.Forms.Label();
            this.Percent2 = new System.Windows.Forms.Label();
            this.Percent3 = new System.Windows.Forms.Label();
            this.TiePercent = new System.Windows.Forms.Label();
            this.OPercent = new System.Windows.Forms.Label();
            this.AICheck = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
            this.SuspendLayout();
            // 
            // grid
            // 
            this.grid.Image = ((System.Drawing.Image)(resources.GetObject("grid.Image")));
            this.grid.Location = new System.Drawing.Point(12, 12);
            this.grid.Name = "grid";
            this.grid.Size = new System.Drawing.Size(460, 466);
            this.grid.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.grid.TabIndex = 0;
            this.grid.TabStop = false;
            // 
            // square1
            // 
            this.square1.BackColor = System.Drawing.Color.White;
            this.square1.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.square1.Location = new System.Drawing.Point(73, 76);
            this.square1.Name = "square1";
            this.square1.Size = new System.Drawing.Size(109, 109);
            this.square1.TabIndex = 1;
            this.square1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.square1.Click += new System.EventHandler(this.square1_Click);
            // 
            // square2
            // 
            this.square2.BackColor = System.Drawing.Color.White;
            this.square2.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.square2.Location = new System.Drawing.Point(188, 76);
            this.square2.Name = "square2";
            this.square2.Size = new System.Drawing.Size(109, 109);
            this.square2.TabIndex = 2;
            this.square2.Text = " ";
            this.square2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.square2.Click += new System.EventHandler(this.square2_Click);
            // 
            // square3
            // 
            this.square3.BackColor = System.Drawing.Color.White;
            this.square3.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.square3.Location = new System.Drawing.Point(303, 76);
            this.square3.Name = "square3";
            this.square3.Size = new System.Drawing.Size(109, 109);
            this.square3.TabIndex = 3;
            this.square3.Text = "  ";
            this.square3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.square3.Click += new System.EventHandler(this.square3_Click);
            // 
            // square4
            // 
            this.square4.BackColor = System.Drawing.Color.White;
            this.square4.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.square4.Location = new System.Drawing.Point(73, 191);
            this.square4.Name = "square4";
            this.square4.Size = new System.Drawing.Size(109, 109);
            this.square4.TabIndex = 4;
            this.square4.Text = "   ";
            this.square4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.square4.Click += new System.EventHandler(this.square4_Click);
            // 
            // square5
            // 
            this.square5.BackColor = System.Drawing.Color.White;
            this.square5.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.square5.Location = new System.Drawing.Point(188, 191);
            this.square5.Name = "square5";
            this.square5.Size = new System.Drawing.Size(109, 109);
            this.square5.TabIndex = 5;
            this.square5.Text = "    ";
            this.square5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.square5.Click += new System.EventHandler(this.square5_Click);
            // 
            // square6
            // 
            this.square6.BackColor = System.Drawing.Color.White;
            this.square6.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.square6.Location = new System.Drawing.Point(303, 191);
            this.square6.Name = "square6";
            this.square6.Size = new System.Drawing.Size(109, 109);
            this.square6.TabIndex = 6;
            this.square6.Text = "     ";
            this.square6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.square6.Click += new System.EventHandler(this.square6_Click);
            // 
            // square7
            // 
            this.square7.BackColor = System.Drawing.Color.White;
            this.square7.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.square7.Location = new System.Drawing.Point(73, 306);
            this.square7.Name = "square7";
            this.square7.Size = new System.Drawing.Size(109, 109);
            this.square7.TabIndex = 7;
            this.square7.Text = "      ";
            this.square7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.square7.Click += new System.EventHandler(this.square7_Click);
            // 
            // square8
            // 
            this.square8.BackColor = System.Drawing.Color.White;
            this.square8.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.square8.Location = new System.Drawing.Point(188, 306);
            this.square8.Name = "square8";
            this.square8.Size = new System.Drawing.Size(109, 109);
            this.square8.TabIndex = 8;
            this.square8.Text = "       ";
            this.square8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.square8.Click += new System.EventHandler(this.square8_Click);
            // 
            // square9
            // 
            this.square9.BackColor = System.Drawing.Color.White;
            this.square9.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.square9.Location = new System.Drawing.Point(303, 306);
            this.square9.Name = "square9";
            this.square9.Size = new System.Drawing.Size(109, 109);
            this.square9.TabIndex = 9;
            this.square9.Text = "        ";
            this.square9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.square9.Click += new System.EventHandler(this.square9_Click);
            // 
            // clear
            // 
            this.clear.Location = new System.Drawing.Point(188, 484);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(109, 23);
            this.clear.TabIndex = 10;
            this.clear.Text = "Clear";
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // playerXLabel
            // 
            this.playerXLabel.AutoSize = true;
            this.playerXLabel.BackColor = System.Drawing.Color.White;
            this.playerXLabel.Location = new System.Drawing.Point(65, 34);
            this.playerXLabel.Name = "playerXLabel";
            this.playerXLabel.Size = new System.Drawing.Size(49, 13);
            this.playerXLabel.TabIndex = 11;
            this.playerXLabel.Text = "Player X:";
            // 
            // playerYLabel
            // 
            this.playerYLabel.AutoSize = true;
            this.playerYLabel.BackColor = System.Drawing.Color.White;
            this.playerYLabel.Location = new System.Drawing.Point(345, 34);
            this.playerYLabel.Name = "playerYLabel";
            this.playerYLabel.Size = new System.Drawing.Size(50, 13);
            this.playerYLabel.TabIndex = 12;
            this.playerYLabel.Text = "Player O:";
            // 
            // OScore
            // 
            this.OScore.AutoSize = true;
            this.OScore.BackColor = System.Drawing.Color.White;
            this.OScore.Location = new System.Drawing.Point(400, 34);
            this.OScore.Name = "OScore";
            this.OScore.Size = new System.Drawing.Size(13, 13);
            this.OScore.TabIndex = 13;
            this.OScore.Text = "0";
            // 
            // XScore
            // 
            this.XScore.AutoSize = true;
            this.XScore.BackColor = System.Drawing.Color.White;
            this.XScore.Location = new System.Drawing.Point(120, 34);
            this.XScore.Name = "XScore";
            this.XScore.Size = new System.Drawing.Size(13, 13);
            this.XScore.TabIndex = 14;
            this.XScore.Text = "0";
            // 
            // turnLabel
            // 
            this.turnLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.turnLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.turnLabel.Location = new System.Drawing.Point(168, 444);
            this.turnLabel.Name = "turnLabel";
            this.turnLabel.Size = new System.Drawing.Size(144, 23);
            this.turnLabel.TabIndex = 15;
            this.turnLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tiesLabel
            // 
            this.tiesLabel.AutoSize = true;
            this.tiesLabel.BackColor = System.Drawing.Color.White;
            this.tiesLabel.Location = new System.Drawing.Point(204, 34);
            this.tiesLabel.Name = "tiesLabel";
            this.tiesLabel.Size = new System.Drawing.Size(64, 13);
            this.tiesLabel.TabIndex = 16;
            this.tiesLabel.Text = "Tie Games: ";
            // 
            // TieScore
            // 
            this.TieScore.AutoSize = true;
            this.TieScore.BackColor = System.Drawing.Color.White;
            this.TieScore.Location = new System.Drawing.Point(274, 34);
            this.TieScore.Name = "TieScore";
            this.TieScore.Size = new System.Drawing.Size(13, 13);
            this.TieScore.TabIndex = 17;
            this.TieScore.Text = "0";
            // 
            // XPercent
            // 
            this.XPercent.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.XPercent.BackColor = System.Drawing.Color.White;
            this.XPercent.Location = new System.Drawing.Point(80, 47);
            this.XPercent.Name = "XPercent";
            this.XPercent.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.XPercent.Size = new System.Drawing.Size(68, 13);
            this.XPercent.TabIndex = 18;
            this.XPercent.Text = "0.00";
            this.XPercent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Percent1
            // 
            this.Percent1.AutoSize = true;
            this.Percent1.BackColor = System.Drawing.Color.White;
            this.Percent1.Location = new System.Drawing.Point(146, 47);
            this.Percent1.Name = "Percent1";
            this.Percent1.Size = new System.Drawing.Size(15, 13);
            this.Percent1.TabIndex = 19;
            this.Percent1.Text = "%";
            // 
            // Percent2
            // 
            this.Percent2.AutoSize = true;
            this.Percent2.BackColor = System.Drawing.Color.White;
            this.Percent2.Location = new System.Drawing.Point(300, 47);
            this.Percent2.Name = "Percent2";
            this.Percent2.Size = new System.Drawing.Size(15, 13);
            this.Percent2.TabIndex = 20;
            this.Percent2.Text = "%";
            // 
            // Percent3
            // 
            this.Percent3.AutoSize = true;
            this.Percent3.BackColor = System.Drawing.Color.White;
            this.Percent3.Location = new System.Drawing.Point(426, 47);
            this.Percent3.Name = "Percent3";
            this.Percent3.Size = new System.Drawing.Size(15, 13);
            this.Percent3.TabIndex = 21;
            this.Percent3.Text = "%";
            // 
            // TiePercent
            // 
            this.TiePercent.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TiePercent.BackColor = System.Drawing.Color.White;
            this.TiePercent.Location = new System.Drawing.Point(234, 47);
            this.TiePercent.Name = "TiePercent";
            this.TiePercent.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TiePercent.Size = new System.Drawing.Size(68, 13);
            this.TiePercent.TabIndex = 22;
            this.TiePercent.Text = "0.00";
            this.TiePercent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OPercent
            // 
            this.OPercent.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OPercent.BackColor = System.Drawing.Color.White;
            this.OPercent.Location = new System.Drawing.Point(360, 47);
            this.OPercent.Name = "OPercent";
            this.OPercent.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.OPercent.Size = new System.Drawing.Size(68, 13);
            this.OPercent.TabIndex = 23;
            this.OPercent.Text = "0.00";
            this.OPercent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // AICheck
            // 
            this.AICheck.Appearance = System.Windows.Forms.Appearance.Button;
            this.AICheck.AutoSize = true;
            this.AICheck.BackColor = System.Drawing.Color.Transparent;
            this.AICheck.Location = new System.Drawing.Point(76, 444);
            this.AICheck.Name = "AICheck";
            this.AICheck.Size = new System.Drawing.Size(56, 23);
            this.AICheck.TabIndex = 24;
            this.AICheck.Text = "AI mode";
            this.AICheck.UseVisualStyleBackColor = false;
            this.AICheck.CheckedChanged += new System.EventHandler(this.AICheck_CheckedChanged);
            // 
            // TicTacToe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 507);
            this.Controls.Add(this.AICheck);
            this.Controls.Add(this.OPercent);
            this.Controls.Add(this.TiePercent);
            this.Controls.Add(this.Percent3);
            this.Controls.Add(this.Percent2);
            this.Controls.Add(this.Percent1);
            this.Controls.Add(this.XPercent);
            this.Controls.Add(this.TieScore);
            this.Controls.Add(this.tiesLabel);
            this.Controls.Add(this.turnLabel);
            this.Controls.Add(this.XScore);
            this.Controls.Add(this.OScore);
            this.Controls.Add(this.playerYLabel);
            this.Controls.Add(this.playerXLabel);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.square9);
            this.Controls.Add(this.square8);
            this.Controls.Add(this.square7);
            this.Controls.Add(this.square6);
            this.Controls.Add(this.square5);
            this.Controls.Add(this.square4);
            this.Controls.Add(this.square3);
            this.Controls.Add(this.square2);
            this.Controls.Add(this.square1);
            this.Controls.Add(this.grid);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TicTacToe";
            this.Text = "Tic-Tac-Toe";
            ((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox grid;
        private System.Windows.Forms.Label square1;
        private System.Windows.Forms.Label square2;
        private System.Windows.Forms.Label square3;
        private System.Windows.Forms.Label square4;
        private System.Windows.Forms.Label square5;
        private System.Windows.Forms.Label square6;
        private System.Windows.Forms.Label square7;
        private System.Windows.Forms.Label square8;
        private System.Windows.Forms.Label square9;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Label playerXLabel;
        private System.Windows.Forms.Label playerYLabel;
        private System.Windows.Forms.Label OScore;
        private System.Windows.Forms.Label XScore;
        private System.Windows.Forms.Label turnLabel;
        private System.Windows.Forms.Label tiesLabel;
        private System.Windows.Forms.Label TieScore;
        private System.Windows.Forms.Label XPercent;
        private System.Windows.Forms.Label Percent1;
        private System.Windows.Forms.Label Percent2;
        private System.Windows.Forms.Label Percent3;
        private System.Windows.Forms.Label TiePercent;
        private System.Windows.Forms.Label OPercent;
        private System.Windows.Forms.CheckBox AICheck;
    }
}

