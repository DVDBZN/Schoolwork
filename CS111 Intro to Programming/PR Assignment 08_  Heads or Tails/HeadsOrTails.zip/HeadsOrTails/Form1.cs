﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HeadsOrTails
{
    public partial class Form1 : Form
    {
        Random rand = new Random();
        Image heads = Image.FromFile("C:/Users/dbozin60/OneDrive/CS111_SI/HeadsOrTails/Resources/Heads2.bmp");
        Image tails = Image.FromFile("C:/Users/dbozin60/OneDrive/CS111_SI/HeadsOrTails/Resources/Tails2.bmp");

        Image guess;
        int score = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //pictureBox1.Padding = new Padding(0, 0, 0, 0);
            //pictureBox1.Image = heads;
            guess = heads;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //pictureBox1.Padding = new Padding(0, 0, 0, 0);
            //pictureBox1.Image = tails;
            guess = tails;
        }

        private async void button3_Click(object sender, EventArgs e)
        {
            /*spinQuarter = rand.Next(20, 25);

            for (int i = 0; i < spinQuarter; i++)
            {
                pictureBox1.Image = heads;
                i++;
                await PutTaskDelay();
                pictureBox1.Image = tails;
                i++;
            }*/

            for (int o = 0; o < rand.Next(3, 7); o++)
            {
                pictureBox1.Size = new Size(0, 209);
                pictureBox1.Image = heads;

                for (int i = 0; i < 240; i += 20)
                {
                    pictureBox1.Padding = new Padding(119 - i / 2, 0, 0, 0);
                    pictureBox1.Size = new Size(i, 209);
                    await PutTaskDelay();
                }

                for (int i = 240; i > 0; i -= 20)
                {
                    pictureBox1.Padding = new Padding(119 - i / 2, 0, 0, 0);
                    pictureBox1.Size = new Size(i, 209);
                    await PutTaskDelay();
                }

                pictureBox1.Size = new Size(0, 209);
                pictureBox1.Image = tails;

                for (int i = 0; i < 240; i += 20)
                {
                    pictureBox1.Padding = new Padding(119 - i / 2, 0, 0, 0);
                    pictureBox1.Size = new Size(i, 209);
                    await PutTaskDelay();
                }

                for (int i = 240; i > 0; i -= 20)
                {
                    pictureBox1.Padding = new Padding(119 - i / 2, 0, 0, 0);
                    pictureBox1.Size = new Size(i, 209);
                    await PutTaskDelay();
                }
            }

            int land = rand.Next(0, 2);
            pictureBox1.Padding = new Padding(0, 0, 0, 0);

            if (land == 0)
                pictureBox1.Image = tails;
            else
                pictureBox1.Image = heads;

            for (int i = 0; i < 240; i += 20)
            {
                pictureBox1.Padding = new Padding(119 - i / 2, 0, 0, 0);
                pictureBox1.Size = new Size(i, 209);
                await PutTaskDelay();
            }

            if (guess == pictureBox1.Image)
            {
                MessageBox.Show("Correct!");
                score++;
                textBox1.Text = score.ToString();
            }

            else
            {
                MessageBox.Show("Incorrect!");
            }
        }

        async Task PutTaskDelay()
        {
            await Task.Delay(1);
            Console.Write("");
        }
    }
}