﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ColorMixer
{
    public partial class ColorMixer : Form
    {
        bool locked = false;
        int tempR1 = 0;
        int tempR2 = 0;
        int tempG1 = 0;
        int tempG2 = 0;
        int tempB1 = 0;
        int tempB2 = 0;
        private Control activeControl;

        public ColorMixer()
        {
            InitializeComponent();
            tempR1 = red1.Value;
            tempR2 = red2.Value;
            tempG1 = green1.Value;
            tempG2 = green2.Value;
            tempB1 = blue1.Value;
            tempB2 = blue2.Value;
        }

        private void red1_ValueChanged(object sender, EventArgs e)
        {
            int temp2 = red1.Value;
            redLabel1.Text = red1.Value.ToString();
            updateRGB();

            if (locked && activeControl == red1)
            {
                if (temp2 < tempR1)
                {
                    red2.Value += tempR1 - temp2;
                }
                else
                {
                    red2.Value -= temp2 - tempR1;
                }
            }

            tempR1 = temp2;
        }

        private void green1_ValueChanged(object sender, EventArgs e)
        {
            int temp2 = green1.Value;
            greenLabel1.Text = green1.Value.ToString();
            updateRGB();

            if (locked && activeControl == green1)
            {
                if (temp2 < tempG1)
                {
                    green2.Value += tempG1 - temp2;
                }
                else
                {
                    green2.Value -= temp2 - tempG1;
                }
            }

            tempG1 = temp2;
        }

        private void blue1_ValueChanged(object sender, EventArgs e)
        {
            int temp2 = blue1.Value;
            blueLabel1.Text = blue1.Value.ToString();
            updateRGB();

            if (locked && activeControl == blue1)
            {
                if (temp2 < tempB1)
                {
                    blue2.Value += tempB1 - temp2;
                }
                else
                {
                    blue2.Value -= temp2 - tempB1;
                }
            }

            tempB1 = temp2;
        }

        private void red2_ValueChanged(object sender, EventArgs e)
        {
            int temp2 = red2.Value;
            redLabel2.Text = red2.Value.ToString();
            updateRGB();

            if (locked && activeControl == red2)
            {
                if (temp2 < tempR2)
                {
                    red1.Value += tempR2 - temp2;
                }
                else
                {
                    red1.Value -= temp2 - tempR2;
                }
            }

            tempR2 = temp2;
        }

        private void green2_ValueChanged(object sender, EventArgs e)
        {
            int temp2 = green2.Value;
            greenLabel2.Text = green2.Value.ToString();
            updateRGB();

            if (locked && activeControl == green2)
            {
                if (temp2 < tempG2)
                {
                    green1.Value += tempG2 - temp2;
                }
                else
                {
                    green1.Value -= temp2 - tempG2;
                }
            }

            tempG2 = temp2;
        }

        private void blue2_ValueChanged(object sender, EventArgs e)
        {
            int temp2 = blue2.Value;
            blueLabel2.Text = blue2.Value.ToString();
            updateRGB();

            if (locked && activeControl == blue2)
            {
                if (temp2 < tempB2)
                {
                    blue1.Value += tempB2 - temp2;
                }
                else
                {
                    blue1.Value -= temp2 - tempB2;
                }
            }

            tempB2 = temp2;
        }

        private void updateRGB()
        {
            rgbTextBox1.Text = red1.Value.ToString() + "," + green1.Value.ToString() + "," + blue1.Value.ToString();
            rgbTextBox2.Text = red2.Value.ToString() + "," + green2.Value.ToString() + "," + blue2.Value.ToString();

            mixedColorRGB.Text = ((red1.Value + red2.Value) / 2).ToString() + "," + ((green1.Value + green2.Value) / 2).ToString() + "," + ((blue1.Value + blue2.Value) / 2).ToString();
        }

        private void rgbTextBox1_TextChanged(object sender, EventArgs e)
        {
            colorShow1.BackColor = Color.FromArgb(red1.Value, green1.Value, blue1.Value);
        }

        private void rgbTextBox2_TextChanged(object sender, EventArgs e)
        {
            colorShow2.BackColor = Color.FromArgb(red2.Value, green2.Value, blue2.Value);
        }

        private void mixedColorRGB_TextChanged(object sender, EventArgs e)
        {
            mixedColor.BackColor = Color.FromArgb((red1.Value + red2.Value) / 2, (green1.Value + green2.Value) / 2, (blue1.Value + blue2.Value) / 2);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int[] rgb = Array.ConvertAll(rgbTextBox1.Text.Split(','), int.Parse);
                colorShow1.BackColor = Color.FromArgb(rgb[0], rgb[1], rgb[2]);

                red1.Value = rgb[0];
                green1.Value = rgb[1];
                blue1.Value = rgb[2];
            }

            catch
            {
                MessageBox.Show("Values must be numerical values between 0 and 255.");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int[] rgb = Array.ConvertAll(rgbTextBox2.Text.Split(','), int.Parse);
                colorShow2.BackColor = Color.FromArgb(rgb[0], rgb[1], rgb[2]);

                red2.Value = rgb[0];
                green2.Value = rgb[1];
                blue2.Value = rgb[2];
            }

            catch
            {
                MessageBox.Show("Values must be numerical values between 0 and 255.");
            }
        }

        private void update_Click(object sender, EventArgs e)
        {
            try
            {
                int[] rgb = Array.ConvertAll(mixedColorRGB.Text.Split(','), int.Parse);
                mixedColor.BackColor = Color.FromArgb(rgb[0], rgb[1], rgb[2]);

                red1.Value = rgb[0];
                red2.Value = rgb[0];
                green1.Value = rgb[1];
                green2.Value = rgb[1];
                blue1.Value = rgb[2];
                blue2.Value = rgb[2];

                unlockTrackBars();

                if (locked == true)
                    lockTrackBars();
            }

            catch
            {
                MessageBox.Show("Values must be numerical values between 0 and 255.");
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (locked == false)
            {
                lockPicture.Image = Properties.Resources.imgres;
                locked = true;
                mixedColorRGB.ReadOnly = true;

                lockTrackBars();
            }

            else
            {
                lockPicture.Image = Properties.Resources.images;
                locked = false;
                mixedColorRGB.ReadOnly = false;

                unlockTrackBars();
            }
        }

        private void lockTrackBars()
        {
            if (red1.Value + red2.Value <= 255)
            {
                red1.Maximum = red1.Value + red2.Value;
                red2.Maximum = red1.Value + red2.Value;
            }

            else if (red1.Value + red2.Value > 255)
            {
                red1.Minimum = (red1.Value + red2.Value) - 255;
                red2.Minimum = (red1.Value + red2.Value) - 255;
            }

            if (green1.Value + green2.Value <= 255)
            {
                green1.Maximum = green1.Value + green2.Value;
                green2.Maximum = green1.Value + green2.Value;
            }

            else if (green1.Value + green2.Value > 255)
            {
                green1.Minimum = (green1.Value + green2.Value) - 255;
                green2.Minimum = (green1.Value + green2.Value) - 255;
            }

            if (blue1.Value + blue2.Value <= 255)
            {
                blue1.Maximum = blue1.Value + blue2.Value;
                blue2.Maximum = blue1.Value + blue2.Value;
            }

            else if (blue1.Value + blue2.Value > 255)
            {
                blue1.Minimum = (blue1.Value + blue2.Value) - 255;
                blue2.Minimum = (blue1.Value + blue2.Value) - 255;
            }
        }

        private void unlockTrackBars()
        {
            red1.Maximum = 255;
            red1.Minimum = 0;
            red2.Maximum = 255;
            red2.Minimum = 0;

            green1.Maximum = 255;
            green1.Minimum = 0;
            green2.Maximum = 255;
            green2.Minimum = 0;

            blue1.Maximum = 255;
            blue1.Minimum = 0;
            blue2.Maximum = 255;
            blue2.Minimum = 0;
        }

        private void red1_MouseHover(object sender, EventArgs e)
        {
            activeControl = red1;
        }

        private void red2_MouseHover(object sender, EventArgs e)
        {
            activeControl = red2;
        }

        private void green1_MouseHover(object sender, EventArgs e)
        {
            activeControl = green1;
        }

        private void green2_MouseHover(object sender, EventArgs e)
        {
            activeControl = green2;
        }

        private void blue1_MouseHover(object sender, EventArgs e)
        {
            activeControl = blue1;
        }

        private void blue2_MouseHover(object sender, EventArgs e)
        {
            activeControl = blue2;
        }
    }
}