#ifndef INVALIDFORMAT
#define INVALIDFORMAT
#include <exception>

//I was not able to implement exception handling before 3:00
class InvalidFormat : public exception
{
public:
	
};
#endif